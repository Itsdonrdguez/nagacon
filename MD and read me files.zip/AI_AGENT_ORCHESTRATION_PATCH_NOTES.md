# AI Agent Orchestration Patch

This patch turns agents into reusable orchestrated workflows instead of isolated one-off calls.

## Why this implementation is the right one

The goal is to make agent runs:
- reusable
- chained
- auditable
- visible in the workspace

So this patch introduces:

- structured `agent_runs`
- orchestration endpoint
- orchestration service
- workspace trigger
- analytics enhancement for company context

## What this gives you

Inside the workspace, the user can now:
1. choose which agents to run
2. run them in sequence
3. store each run
4. review the resulting run history

The current orchestration supports:
- opportunity analyzer
- vendor discovery
- pricing
- proposal

## Why this is practical
This version is synchronous and simple.
That is the right choice for now because:
- it is easier to debug locally
- it gives immediate user feedback
- it still stores all runs for auditability

Later, this can evolve into:
- background jobs
- chained dependencies
- retries
- scheduled orchestration
- agent graphs

## Files included
- `backend/app/models/agent_run.py`
- `backend/app/schemas/agent.py`
- `backend/app/repositories/agents.py`
- `backend/app/services/agents/orchestration.py`
- `backend/app/api/routes/agents.py`
- `backend/app/services/analytics/metrics.py` (updated)
- `streamlit_app/api_agents.py`
- `streamlit_app/pages/2_Workspace.py` (updated)
- `streamlit_app/pages/3_Analytics.py` (updated)

## Required follow-up
- include the agents router in FastAPI
- create/apply Alembic migration updates if your agent tables differ
- ensure OpenAI config is set for proposal runs
- replace the analyzer stub with your full opportunity analyzer when ready
