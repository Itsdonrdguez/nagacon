# Company Profile + Past Performance Integration Patch

This patch makes proposal assistance company-aware.

## Why this implementation is the right one

The goal is to improve proposal drafts using:
- the company's core identity
- differentiators
- certifications
- NAICS footprint
- relevant past performance

That lets the app generate stronger, more tailored content than workspace-only prompts.

## What this patch adds

### Data model
- `company_profiles`
- `past_performances`

### API
- create/get/update company profile
- create/list/update past performance

### Proposal agent
The proposal agent now:
- loads the first company profile
- loads past performance records
- ranks/selects the most relevant records for the opportunity
- injects company profile + past performance into the prompt

### Analytics
Analytics now also show:
- `past_performance_count`

## Why this is practical
This version assumes a single-company local-first app for now.
That keeps the workflow simple while still making drafts company-aware.

Later, for SaaS, this can evolve to:
- per-organization profiles
- per-organization past performance
- profile selection by workspace/org context

## Files included
- `backend/app/models/company_profile.py`
- `backend/app/models/past_performance.py`
- `backend/app/schemas/company.py`
- `backend/app/repositories/company.py`
- `backend/app/api/routes/company.py`
- `backend/app/services/agents/proposal_agent.py` (updated)
- `backend/app/services/analytics/metrics.py` (updated)
- `streamlit_app/api_company.py`
- `streamlit_app/pages/2_Workspace.py` (updated)
- `streamlit_app/pages/3_Analytics.py` (updated)

## Required follow-up
- include the company router in FastAPI
- create Alembic migrations for:
  - `company_profiles`
  - `past_performances`
- ensure OpenAI config remains set
