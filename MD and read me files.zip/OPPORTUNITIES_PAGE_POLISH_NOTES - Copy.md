# Opportunities Page Cleanup + Workspace Launch Polish

Included files:
- `streamlit_app/api_opportunities.py`
- `streamlit_app/pages/1_Opportunities.py`

## What changed
- simplified the opportunities page
- added search + source filter
- added clear SAM / DIBBS ingest actions
- added a direct "Launch Workspace" flow
- stores selected opportunity in `st.session_state["workspace_id"]`
- uses `st.switch_page("pages/2_Workspace.py")` to open the workspace

## Why this is better
- cleaner table-first workflow
- direct path from opportunity list into workspace
- consistent with the project goal of keeping the opportunities page simple
- keeps the workspace as the real action center

## Notes on the backend snippets you shared
### Good
- `deduplicate.py` is in good shape
- `ingest.py` flow is now correct: exact first, fuzzy second
- `query.py` stubs are fine for now
- SAM scraper is acceptable as a scaffold

### Fix needed
In `backend/app/services/scrapers/dibbs_scraper.py`, add:

```python
from typing import List, Dict, Optional
```

because `Optional` is used in `safe_parse_date()`.

Also keep DIBBS labeled as a scaffold until selectors and pagination are validated locally.
