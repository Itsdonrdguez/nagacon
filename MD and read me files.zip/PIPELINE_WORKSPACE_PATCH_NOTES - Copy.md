# Pipeline + Workspace Patch

This patch turns the pipeline into the source of truth for bid / no-bid workflow.

## What this changes

### Backend
Adds:
- `backend/app/models/pipeline_item.py`
- `backend/app/schemas/pipeline.py`
- `backend/app/repositories/pipeline.py`
- `backend/app/services/pipeline/decision.py`
- `backend/app/api/routes/pipeline.py`

Updates:
- `backend/app/services/opportunities/query.py`

### Frontend
Adds:
- `streamlit_app/api_pipeline.py`

Updates:
- `streamlit_app/pages/2_Workspace.py`

## Why this implementation is the right one

The goal is to make the workspace the action center for pursuit decisions without creating two conflicting status systems.

So this patch uses:

- `opportunities` = market/intake record
- `pipeline_items` = pursuit/decision record

That means:
- one opportunity can have one pipeline item
- pipeline owns:
  - decision_status
  - owner
  - priority
  - probability_of_win
  - notes
  - target_submit_date

## API shape

Routes added:

- `GET /api/pipeline/{pipeline_id}`
- `GET /api/pipeline/by-opportunity/{opportunity_id}`
- `POST /api/pipeline/by-opportunity/{opportunity_id}`
- `POST /api/pipeline/`
- `PATCH /api/pipeline/{pipeline_id}`

## Workspace behavior

Inside the workspace:

- if no pipeline row exists:
  - show **Initialize Pipeline**
- once initialized:
  - show editable pipeline section
  - allow status changes
  - save notes
  - save owner
  - save priority
  - save pWin
  - save target submit date

## Migration reminder

Create and apply an Alembic migration for `pipeline_items`.

Recommended DB rules:
- unique constraint on `opportunity_id`
- enum column for `decision_status`
