# Proposal Assistance + Analytics Patch

This patch adds proposal assistance tied to the workspace and a simple analytics dashboard.

## Why this is the right implementation

The goal is to generate useful first-draft proposal support content from the actual workspace state:
- opportunity details
- parsed fields
- pipeline
- vendor shortlist
- quote scenarios

At the same time, analytics should summarize live system activity in a simple backend-driven way.

## Proposal assistance
The proposal agent:
- loads workspace data
- compiles a structured prompt
- calls OpenAI
- returns draft sections:
  - executive_summary
  - compliance_matrix_starter
  - vendor_outreach_email
  - pricing_notes
  - risks_and_gaps
- stores the run in `agent_runs`

## Analytics
The analytics service returns:
- total opportunities
- due soon in 7 days
- pipeline stage counts
- active pipeline items
- quote scenarios
- weighted pipeline value

Weighted pipeline value is calculated as:
- sum(total_quote_value * pWin)

That is much more useful than a plain count.

## Files included
- `backend/app/services/agents/proposal_agent.py`
- `backend/app/api/routes/agents.py`
- `backend/app/services/analytics/metrics.py`
- `backend/app/api/routes/analytics.py`
- `streamlit_app/api_agents.py`
- `streamlit_app/api_analytics.py`
- `streamlit_app/pages/2_Workspace.py` (updated)
- `streamlit_app/pages/3_Analytics.py`

## Required follow-up
- include the new routers in FastAPI
- ensure `OPENAI_API_KEY` is configured
- ensure existing `AgentRunRepository` and `AgentRunCreate` are present
- create any needed Alembic migration if your agent table/schema changed
