# Quote Scenarios + Workspace Integration Patch

This patch adds practical quote scenario generation tied to shortlisted vendors.

## Why this implementation is the right one

The goal is not to build a full pricing engine on day one.
The goal is to let the user create, compare, and persist quote scenarios directly inside the workspace.

So this patch uses:
- a `quotes` table
- backend calculation of:
  - sell_price
  - total_price
- quotes linked to:
  - opportunity
  - optional vendor
- workspace summary returns quote scenarios
- workspace UI lets the user:
  - add quote scenarios
  - view totals
  - delete quotes

## What this gives you

Inside the workspace, the user can now:
1. discover vendors
2. pick a shortlisted vendor
3. create quote scenarios with:
   - line item
   - quantity
   - unit cost
   - markup %
   - assumptions
4. persist those scenarios
5. compare totals later

## Why this is a good first version
- backend-driven calculations
- persistent and auditable
- tied directly to opportunity + vendor
- easy to extend later with:
  - taxes
  - shipping
  - discounts
  - multi-line quote sets
  - best-price recommendations

## Files included
- `backend/app/models/quote.py`
- `backend/app/schemas/quote.py`
- `backend/app/repositories/quotes.py`
- `backend/app/services/quotes/calculations.py`
- `backend/app/api/routes/quotes.py`
- `backend/app/services/opportunities/query.py` (updated)
- `streamlit_app/api_quotes.py`
- `streamlit_app/pages/2_Workspace.py` (updated)

## Important router reminder
Include the new router in FastAPI:
- `app.include_router(quotes.router)`

## Migration reminder
Create and apply an Alembic migration for:
- `quotes`

## Recommended next step
After this, the strongest next feature is probably:
- proposal assistance using:
  - opportunity
  - pipeline notes
  - vendor shortlist
  - quote scenarios
