# NagaCon Vendor Debug Bundle

This bundle gives you ready-to-paste code for verifying whether the app is actually fetching and saving vendor intelligence.

## Files included

- `backend/app/api/vendors.py`
  - Adds `GET /api/vendors/debug/{opportunity_id}`
- `streamlit_app/api_vendors.py`
  - Adds `vendors_get_debug(opportunity_id)`
- `streamlit_app/pages/2_Workspace.py`
  - Adds a Streamlit debug button and JSON output blocks
- `backend/app/services/rfq_parser.py`
  - Debug print snippets for text selection and parsing
- `backend/app/services/vendor_debug_snippets.py`
  - Debug print snippets for lead sync and quote seeding
- `backend/app/main_router_note.txt`
  - Reminder to include the vendors router in `main.py`

## How to use

1. Paste the new `/debug/{opportunity_id}` route into your existing `backend/app/api/vendors.py`.
2. Add `vendors_get_debug()` to your existing `streamlit_app/api_vendors.py`.
3. Paste the `Vendor Fetch Debug` block into `streamlit_app/pages/2_Workspace.py`.
4. Add the RFQ parser print statements to your parser functions.
5. Add the vendor/quote debug prints into your vendor service functions.
6. Restart backend and Streamlit.

## Fastest test

Open a workspace and click **Run Vendor Debug**.

You should see:
- `text_debug.text_source`
- `text_debug.text_length`
- `parsed_debug.approved_source_count`
- `db_debug.lead_count`
- `db_debug.quote_count`

## Direct API test

In the browser:

`http://127.0.0.1:8000/api/vendors/debug/52`

Replace `52` with a real opportunity id.

## How to interpret results

### If `text_length = 0`
Your RFQ text extraction is failing.

### If `text_length > 0` but `approved_source_count = 0`
Your parser regex/patterns need work.

### If parsing works but `lead_count = 0`
Lead sync is failing or not being called.

### If leads exist but `quote_count = 0`
Quote seeding is filtering too aggressively, usually because CAGE is missing.
