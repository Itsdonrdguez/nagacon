
NagaCon USAspending Seed-to-Leads Bundle

What this adds
- Research route: POST /api/research/usaspending/opportunities/{opportunity_id}
- Seed route: POST /api/research/usaspending/opportunities/{opportunity_id}/seed-leads
- Streamlit API helper
- Workspace snippet for a Research section

Why this matters
- Your current parser-based vendor sync is mounted and working, but creates 0 leads when the solicitation lacks usable parsed vendor text.
- Your USAspending research route already returns strong likely vendors for opportunity 49, but those vendors are not yet being saved into vendor_leads.
- This bundle bridges that gap by seeding top USAspending candidates into vendor_leads using source_type=USASPENDING_AWARD_HISTORY.

Notes
- Built to fit your current codebase using:
  - app.core.deps.get_db
  - app.models.opportunity.Opportunity
  - app.models.vendor.VendorLead
- It avoids depending on a separate generic Vendor model, because your current live app uses VendorLead and VendorQuote.

After copying files
1) Update backend/app/main.py using MAIN_PATCH.txt
2) Restart backend
3) Test:
   Invoke-RestMethod -Method Post "http://127.0.0.1:8000/api/research/usaspending/opportunities/49"
   Invoke-RestMethod -Method Post "http://127.0.0.1:8000/api/research/usaspending/opportunities/49/seed-leads"
   Invoke-RestMethod "http://127.0.0.1:8000/api/vendors/leads?opportunity_id=49" | ConvertTo-Json -Depth 10

Expected outcome
- vendor_leads should no longer be empty for opportunities where USAspending research returns candidates.
- vendor-email can then use a real vendor_lead_id for opportunity-specific draft generation.

Relevant current app evidence
- vendors/leads/sync is mounted but returned created=0, updated=0, text_source={} in your diagnostic report.
- USAspending research returned awards_found=50 and populated likely_vendors for opportunity 49.
