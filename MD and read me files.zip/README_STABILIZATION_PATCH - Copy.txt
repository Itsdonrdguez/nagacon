NagaCon Backend Stabilization Patch

What this pack is for
- Get the backend booting again without chasing import mismatches.
- Stabilize the current parser import chain.
- Keep /api/vendors routes alive so Streamlit stops crashing on startup.

What is included
- backend/app/services/rfq_parser.py
  Compatibility-safe parser:
  * no top-level debug NameError
  * no hard dependency on app.models.file_record
  * falls back to RAW_TEXT if file model cannot be resolved
- backend/app/api/vendors.py
  Compatibility-safe placeholder vendor routes:
  * /api/vendors/health
  * /api/vendors/leads
  * /api/vendors/quotes
  * /api/vendors/debug/{opportunity_id}
  * /api/vendors/leads/sync
  * /api/vendors/quotes/seed

Important
- This is a stabilization patch, not the final vendor workflow.
- The vendor routes are safe placeholders so the backend can start and the UI can keep moving.
- Once the app is stable, the next step is wiring these routes back to your real models/services.

Replace these files
- backend/app/services/rfq_parser.py
- backend/app/api/vendors.py

Then restart backend
- uvicorn app.main:app --reload
