# State / Local Opportunity Scrapers Patch

This patch expands ingestion beyond federal sources by adding practical state/local scraper scaffolds.

## Why this is the right implementation

The goal is not to pretend these scrapers are production-finished on day one.
The goal is to expand your ingestion funnel with a modular structure that can be validated and refined source by source.

So this patch adds:
- a shared state/local scraper module
- source-specific fetchers for:
  - eVA (Virginia)
  - Maryland
  - DC
- scraper routes
- opportunities page controls for state/local ingestion

## Why this is practical
This version:
- reuses your existing normalize + ingest flow
- outputs `RawOpportunity`
- keeps parsing generic enough to iterate locally
- labels these scrapers as scaffolds so you can refine selectors per site

## Files included
- `backend/app/services/scrapers/state_local_scraper.py`
- `backend/app/api/routes/scrapers.py`
- `streamlit_app/api_scrapers.py`
- `streamlit_app/pages/1_Opportunities.py`

## Important notes
- validate selectors locally for each source
- some sites may require session handling or POST-based pagination
- some dates/fields may need source-specific mapping adjustments
- this patch adds no new tables; it plugs into your existing ingestion flow

## Recommended test flow
1. Run one source at a time
2. Inspect inserted/updated/skipped counts
3. Check stored `raw_payload`
4. Refine selectors on any failing source
5. Then run all state/local sources together
