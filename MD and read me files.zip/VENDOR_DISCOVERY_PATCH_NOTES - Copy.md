# Vendor Discovery + Workspace Integration Patch

This patch adds a practical rule-based vendor discovery flow and connects it directly to the workspace.

## Why this implementation is the right one

The goal is not to build a perfect vendor-intelligence engine on day one.
The goal is to create a backend-driven shortlist that is:

- simple
- persistent
- tied to the opportunity
- visible inside the workspace
- easy to improve later with AI or external APIs

So this patch uses:

- `vendors` as the vendor master table
- `vendor_opportunity_matches` as the join table
- rule-based scoring for now
- workspace summary to expose matches to Streamlit

## What this gives you

From the workspace, the user can now:

1. click **Discover Vendors**
2. let the backend score likely vendors using:
   - NAICS overlap
   - title/description keywords
   - existing vendor capability text
3. store the shortlist in `vendor_opportunity_matches`
4. immediately view matches in the workspace

## Why this is a good first version

This implementation is practical because it:

- does not require external APIs yet
- is idempotent through create-or-update matching
- does not conflict with your existing vendor leads / quote flows
- can later be upgraded with:
  - SBA search
  - SAM entity lookup
  - AI ranking
  - embeddings

## Files included
- `backend/app/models/vendor_opportunity_match.py`
- `backend/app/schemas/vendor_match.py`
- `backend/app/repositories/vendor_matches.py`
- `backend/app/services/vendors/discovery.py`
- `backend/app/api/vendor_discovery.py`
- `backend/app/api/workspace.py` (updated summary)
- `streamlit_app/api_vendor_discovery.py`
- `streamlit_app/pages/2_Workspace.py` (updated)

## Migration reminder
Create an Alembic migration for:
- `vendor_opportunity_matches`
- unique constraint on `(vendor_id, opportunity_id)`

## Router reminder
Include the new router in your FastAPI app:
- `app.include_router(vendor_discovery.router)`

## Best next steps after this
Once this is working, the next logical upgrades are:
- vendor scoring improvements
- quote scenario generation from selected vendors
- proposal assistance using shortlisted vendors
