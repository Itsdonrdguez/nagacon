# Workspace UI + API Integration Patch

Included files:
- `backend/app/api/workspace.py`
- `streamlit_app/api_workspace.py`
- `streamlit_app/pages/2_Workspace.py`

## What changed

### Backend
Added:
- `GET /api/workspace/summary?opp_id=...`
- `POST /api/workspace/decision`

Kept existing:
- parse
- generate checklist
- generate vendors
- generate email
- tasks
- artifacts
- export zip

### Frontend
Replaced the workspace page so it now reads from backend APIs instead of querying PostgreSQL directly.

Main UI sections:
- Overview
- Files
- Tasks
- Artifacts
- Vendors / Quotes

## Why this is better
- Streamlit acts like a client
- workspace data comes from API
- cleaner separation of concerns
- easier SaaS migration later

## Required install
No new dependencies beyond the existing project for this patch.
